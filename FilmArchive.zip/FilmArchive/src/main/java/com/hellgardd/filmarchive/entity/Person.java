package com.hellgardd.filmarchive.entity;

import jakarta.persistence.*;
@Entity
@Table(name="people")
public class Person {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
 private Long id;
 @Column(nullable=false, unique=true, length=120, name="full_name")
 private String fullName;
 public Person() {}
 public Person(String fullName) { this.fullName=fullName; }
 public Long getId() { return id; }
 public String getFullName() { return fullName; }
 public void setFullName(String value) { this.fullName=value; }
}

package com.hellgardd.filmarchive.service;

import com.hellgardd.filmarchive.entity.*;
import com.hellgardd.filmarchive.repository.*;
import jakarta.persistence.EntityManager;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
public class DatabaseInitializationService {
 private final EntityManager em; private final FilmRepository films; private final GenreRepository genres; private final CountryRepository countries;
 private final AgeLimitRepository ages; private final ShootingQualityRepository qualities; private final PersonRepository people; private final boolean seed;
 public DatabaseInitializationService(EntityManager em,FilmRepository films,GenreRepository genres,CountryRepository countries,AgeLimitRepository ages,ShootingQualityRepository qualities,PersonRepository people,@Value("${app.seed-data:true}") boolean seed) {
 this.em=em; this.films=films; this.genres=genres; this.countries=countries; this.ages=ages; this.qualities=qualities; this.people=people; this.seed=seed;
 }
 @Transactional public void initialize() {
 // PostgreSQL expression indexes protect against concurrent case-insensitive duplicate inserts.
 for(String[] index:List.of(new String[]{"films","title"},new String[]{"genres","title"},new String[]{"genres","code"},
 new String[]{"countries","title"},new String[]{"countries","code"},new String[]{"age_limits","category"},new String[]{"age_limits","code"},
 new String[]{"shooting_qualities","type"},new String[]{"people","full_name"})) {
 em.createNativeQuery("CREATE UNIQUE INDEX IF NOT EXISTS ux_"+index[0]+"_"+index[1]+"_ci ON "+index[0]+" (lower("+index[1]+"))").executeUpdate();
 }
 // Demo data are inserted only into a completely empty catalog.
 if(!seed || films.count()+genres.count()+countries.count()+ages.count()+qualities.count()+people.count()>0) return;
 Genre sci=genres.save(new Genre("Фантастика","SCI")), comedy=genres.save(new Genre("Комедия","COM"));
 Genre drama=genres.save(new Genre("Драма","DRA")); genres.save(new Genre("Боевик","ACT"));
 Country usa=countries.save(new Country("США","US")),uk=countries.save(new Country("Великобритания","GB"));
 countries.save(new Country("Франция","FR")); countries.save(new Country("Германия","DE"));
 ages.save(new AgeLimit("0+","0"));
 AgeLimit a6=ages.save(new AgeLimit("6+","6")),a12=ages.save(new AgeLimit("12+","12")),a16=ages.save(new AgeLimit("16+","16"));
 ages.save(new AgeLimit("18+","18"));
 qualities.save(new ShootingQuality("HD")); ShootingQuality full=qualities.save(new ShootingQuality("Full HD")),four=qualities.save(new ShootingQuality("4K"));
 Person keanu=people.save(new Person("Киану Ривз")),laurence=people.save(new Person("Лоренс Фишборн")),carrie=people.save(new Person("Кэрри-Энн Мосс"));
 Person matthew=people.save(new Person("Мэттью Макконахи")),anne=people.save(new Person("Энн Хэтэуэй")),tom=people.save(new Person("Том Хэнкс"));
 Person hugh=people.save(new Person("Хью Грант")),sally=people.save(new Person("Салли Хокинс"));
 addFilm("Матрица","Хакер Нео узнаёт, что привычный мир — компьютерная симуляция.",136,"63000000","467222728","1999-03-31",sci,usa,a16,four,keanu,laurence,carrie);
 addFilm("Интерстеллар","Команда исследователей отправляется в космос, чтобы найти новый дом для человечества.",169,"165000000","701729206","2014-11-06",sci,uk,a12,four,matthew,anne);
 addFilm("Форрест Гамп","История доброго человека, оказавшегося в центре событий своей эпохи.",142,"55000000","678226465","1994-07-06",drama,usa,a12,full,tom);
 addFilm("Приключения Паддингтона 2","Медвежонок ищет подарок для тёти и попадает в неожиданное приключение.",103,"40000000","227992487","2017-11-10",comedy,uk,a6,full,hugh,sally);
 }
 private void addFilm(String title,String description,int duration,String budget,String box,String date,Genre genre,Country country,AgeLimit age,ShootingQuality quality,Person... actors) {
 Film f=new Film(); f.setTitle(title); f.setDescription(description); f.setDuration(duration); f.setBudget(new BigDecimal(budget)); f.setTotalBoxOffice(new BigDecimal(box)); f.setReleaseDate(LocalDate.parse(date));
 f.setGenre(genre); f.setCountry(country); f.setAgeLimit(age); f.setShootingQuality(quality); f.getActors().addAll(Arrays.asList(actors)); films.save(f);
 }
}

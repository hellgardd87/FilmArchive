package com.hellgardd.filmarchive.entity;

import jakarta.persistence.*;
@Entity
@Table(name="genres")
public class Genre {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
 private Long id;
 @Column(nullable=false, unique=true, length=120)
 private String title;
 @Column(nullable=false, unique=true, length=120)
 private String code;
 public Genre() {}
 public Genre(String title, String code) { this.title=title; this.code=code; }
 public Long getId() { return id; }
 public String getTitle() { return title; }
 public void setTitle(String value) { this.title=value; }
 public String getCode() { return code; }
 public void setCode(String value) { this.code=value; }
}

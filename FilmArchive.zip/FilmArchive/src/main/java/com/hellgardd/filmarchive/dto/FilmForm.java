package com.hellgardd.filmarchive.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import org.springframework.format.annotation.DateTimeFormat;
import com.hellgardd.filmarchive.entity.Film;
public class FilmForm {
 @NotBlank(message="Укажите название фильма") @Size(max=200,message="Название: не более 200 символов")
 private String title;
 @Size(max=5000,message="Описание: не более 5000 символов") private String description;
 @NotNull(message="Укажите длительность") @Min(value=1,message="Длительность должна быть больше 0") @Max(value=300,message="Длительность: не более 300 минут")
 private Integer duration;
 @NotNull(message="Укажите бюджет") @DecimalMin(value="0",inclusive=false,message="Бюджет должен быть больше 0") @DecimalMax(value="600000000",inclusive=false,message="Бюджет должен быть меньше 600000000") @Digits(integer=9,fraction=2,message="Бюджет: не более двух знаков после запятой")
 private BigDecimal budget;
 @NotNull(message="Укажите кассовые сборы") @DecimalMin(value="0",inclusive=false,message="Сборы должны быть больше 0") @DecimalMax(value="3000000000",inclusive=false,message="Сборы должны быть меньше 3000000000") @Digits(integer=10,fraction=2,message="Сборы: не более двух знаков после запятой")
 private BigDecimal totalBoxOffice;
 @NotNull(message="Укажите дату выхода") @DateTimeFormat(iso=DateTimeFormat.ISO.DATE)
 private LocalDate releaseDate;
 @NotNull(message="Выберите жанр") @Positive private Long genreId;
 @NotNull(message="Выберите страну") @Positive private Long countryId;
 @NotNull(message="Выберите возрастное ограничение") @Positive private Long ageLimitId;
 @NotNull(message="Выберите качество") @Positive private Long shootingQualityId;
 @NotEmpty(message="Выберите хотя бы одного актёра")
 private Set<@NotNull @Positive Long> actorIds=new LinkedHashSet<>();
 public String getTitle() { return title; }
 public void setTitle(String value) { this.title=value; }
 public String getDescription() { return description; }
 public void setDescription(String value) { this.description=value; }
 public Integer getDuration() { return duration; }
 public void setDuration(Integer value) { this.duration=value; }
 public BigDecimal getBudget() { return budget; }
 public void setBudget(BigDecimal value) { this.budget=value; }
 public BigDecimal getTotalBoxOffice() { return totalBoxOffice; }
 public void setTotalBoxOffice(BigDecimal value) { this.totalBoxOffice=value; }
 public LocalDate getReleaseDate() { return releaseDate; }
 public void setReleaseDate(LocalDate value) { this.releaseDate=value; }
 public Long getGenreId() { return genreId; }
 public void setGenreId(Long value) { this.genreId=value; }
 public Long getCountryId() { return countryId; }
 public void setCountryId(Long value) { this.countryId=value; }
 public Long getAgeLimitId() { return ageLimitId; }
 public void setAgeLimitId(Long value) { this.ageLimitId=value; }
 public Long getShootingQualityId() { return shootingQualityId; }
 public void setShootingQualityId(Long value) { this.shootingQualityId=value; }
 public Set<Long> getActorIds() { return actorIds; }
 public void setActorIds(Set<Long> value) { this.actorIds=value; }
 public FilmForm() {}
 public FilmForm(Film f) {
 title=f.getTitle(); description=f.getDescription(); duration=f.getDuration(); budget=f.getBudget();
 totalBoxOffice=f.getTotalBoxOffice(); releaseDate=f.getReleaseDate(); genreId=f.getGenre().getId();
 countryId=f.getCountry().getId(); ageLimitId=f.getAgeLimit().getId(); shootingQualityId=f.getShootingQuality().getId();
 f.getActors().forEach(p -> actorIds.add(p.getId()));
 }
}

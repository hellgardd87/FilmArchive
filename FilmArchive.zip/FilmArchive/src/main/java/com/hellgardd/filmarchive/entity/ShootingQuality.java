package com.hellgardd.filmarchive.entity;

import jakarta.persistence.*;
@Entity
@Table(name="shooting_qualities")
public class ShootingQuality {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
 private Long id;
 @Column(nullable=false, unique=true, length=120)
 private String type;
 public ShootingQuality() {}
 public ShootingQuality(String type) { this.type=type; }
 public Long getId() { return id; }
 public String getType() { return type; }
 public void setType(String value) { this.type=value; }
}

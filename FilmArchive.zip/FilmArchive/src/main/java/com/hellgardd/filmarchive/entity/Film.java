package com.hellgardd.filmarchive.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
@Entity
@Table(name="films")
public class Film {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false, unique=true, length=200) private String title;
 @Column(length=5000) private String description;
 @Column(nullable=false) private Integer duration;
 @Column(nullable=false, precision=15, scale=2) private BigDecimal budget;
 @Column(name="total_box_office", nullable=false, precision=15, scale=2) private BigDecimal totalBoxOffice;
 @Column(name="release_date", nullable=false) private LocalDate releaseDate;
 @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="genre_id", nullable=false) private Genre genre;
 @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="country_id", nullable=false) private Country country;
 @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="age_limit_id", nullable=false) private AgeLimit ageLimit;
 @ManyToOne(fetch=FetchType.LAZY, optional=false) @JoinColumn(name="shooting_quality_id", nullable=false) private ShootingQuality shootingQuality;
 @ManyToMany
 @JoinTable(name="film_people", joinColumns=@JoinColumn(name="film_id"), inverseJoinColumns=@JoinColumn(name="person_id"),
 uniqueConstraints=@UniqueConstraint(columnNames={"film_id","person_id"}))
 @OrderBy("fullName ASC") private Set<Person> actors=new LinkedHashSet<>();
 public Film() {}
 public Long getId() { return id; }
 public String getTitle() { return title; }
 public void setTitle(String value) { this.title=value; }
 public String getDescription() { return description; }
 public void setDescription(String value) { this.description=value; }
 public Integer getDuration() { return duration; }
 public void setDuration(Integer value) { this.duration=value; }
 public BigDecimal getBudget() { return budget; }
 public void setBudget(BigDecimal value) { this.budget=value; }
 public BigDecimal getTotalBoxOffice() { return totalBoxOffice; }
 public void setTotalBoxOffice(BigDecimal value) { this.totalBoxOffice=value; }
 public LocalDate getReleaseDate() { return releaseDate; }
 public void setReleaseDate(LocalDate value) { this.releaseDate=value; }
 public Genre getGenre() { return genre; }
 public void setGenre(Genre value) { this.genre=value; }
 public Country getCountry() { return country; }
 public void setCountry(Country value) { this.country=value; }
 public AgeLimit getAgeLimit() { return ageLimit; }
 public void setAgeLimit(AgeLimit value) { this.ageLimit=value; }
 public ShootingQuality getShootingQuality() { return shootingQuality; }
 public void setShootingQuality(ShootingQuality value) { this.shootingQuality=value; }
 public Set<Person> getActors() { return actors; }
 public void setActors(Set<Person> value) { this.actors=value; }
 public String getActorNames() { return actors.stream().map(Person::getFullName).sorted().collect(Collectors.joining(", ")); }
}

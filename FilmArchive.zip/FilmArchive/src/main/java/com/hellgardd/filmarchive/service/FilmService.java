package com.hellgardd.filmarchive.service;

import com.hellgardd.filmarchive.entity.*;
import com.hellgardd.filmarchive.dto.FilmForm;
import com.hellgardd.filmarchive.repository.*;
import com.hellgardd.filmarchive.exception.*;
import jakarta.validation.Validator;
import java.time.*;
import java.util.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service @Transactional(readOnly=true)
public class FilmService {
 private final FilmRepository films; private final GenreRepository genres; private final CountryRepository countries;
 private final AgeLimitRepository ages; private final ShootingQualityRepository qualities; private final PersonRepository people;
 private final Clock clock; private final Validator validator; private final TextNormalizer text;
 public FilmService(FilmRepository films,GenreRepository genres,CountryRepository countries,AgeLimitRepository ages,
 ShootingQualityRepository qualities,PersonRepository people,Clock clock,Validator validator,TextNormalizer text) {
 this.films=films; this.genres=genres; this.countries=countries; this.ages=ages; this.qualities=qualities;
 this.people=people; this.clock=clock; this.validator=validator; this.text=text;
 }
 public List<Film> all() { return films.findAllByOrderByTitleAsc(); }
 public Film get(Long id) { return films.findById(id).orElseThrow(() -> new NotFoundException("Фильм не найден")); }
 public FilmForm form(Long id) { return new FilmForm(get(id)); }
 @Transactional public void add(FilmForm form) { save(new Film(),form); }
 @Transactional public void update(Long id,FilmForm form) { save(get(id),form); }
 private void save(Film film,FilmForm form) {
 var violations=validator.validate(form);
 if(!violations.isEmpty()) {
 var violation=violations.iterator().next();
 throw new FormValidationException(violation.getPropertyPath().toString(),violation.getMessage());
 }
 String title=text.normalize(form.getTitle());
 if(title.isBlank()) throw new FormValidationException("title","Название не должно состоять из пробелов");
 if(form.getReleaseDate().isAfter(LocalDate.now(clock))) throw new FormValidationException("releaseDate","Дата выхода не должна быть в будущем");
 boolean duplicate=film.getId()==null ? films.existsByTitleIgnoreCase(title) : films.existsByTitleIgnoreCaseAndIdNot(title,film.getId());
 if(duplicate) throw new FormValidationException("title","Фильм с таким названием уже существует");
 film.setGenre(genres.findById(form.getGenreId()).orElseThrow(() -> new FormValidationException("genreId","Выбранный жанр не найден")));
 film.setCountry(countries.findById(form.getCountryId()).orElseThrow(() -> new FormValidationException("countryId","Выбранная страна не найдена")));
 film.setAgeLimit(ages.findById(form.getAgeLimitId()).orElseThrow(() -> new FormValidationException("ageLimitId","Возрастное ограничение не найдено")));
 film.setShootingQuality(qualities.findById(form.getShootingQualityId()).orElseThrow(() -> new FormValidationException("shootingQualityId","Качество не найдено")));
 var actors=people.findAllById(form.getActorIds());
 if(actors.size()!=form.getActorIds().size()) throw new FormValidationException("actorIds","Один из выбранных актёров больше не существует");
 film.setTitle(title); film.setDescription(form.getDescription()==null ? "" : form.getDescription().strip());
 film.setDuration(form.getDuration()); film.setBudget(form.getBudget()); film.setTotalBoxOffice(form.getTotalBoxOffice()); film.setReleaseDate(form.getReleaseDate());
 film.getActors().clear(); film.getActors().addAll(actors);
 films.saveAndFlush(film);
 }
 @Transactional public void delete(Long id) {
 Film film=get(id); film.getActors().clear(); films.flush(); films.delete(film); films.flush();
 }
}

package com.hellgardd.filmarchive.dto;

import jakarta.validation.constraints.*;
public class QualityForm {
 @NotBlank(message="Заполните название / ФИО") @Size(max=120,message="Не более 120 символов") private String type;
 public String getType() { return type; }
 public void setType(String value) { type=value; }
}

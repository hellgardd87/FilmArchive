package com.hellgardd.filmarchive.dto;

import jakarta.validation.constraints.*;
public class AgeLimitForm {
 @NotBlank(message="Укажите категорию") @Size(max=120,message="Категория: не более 120 символов") private String category;
 @NotBlank(message="Укажите код") @Size(max=120,message="Код: не более 120 символов") private String code;
 public String getCategory() { return category; } public void setCategory(String v) { category=v; }
 public String getCode() { return code; } public void setCode(String v) { code=v; }
}
